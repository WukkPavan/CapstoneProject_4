package TestScripts;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class RestAssuredCapstone {

	public static void main(String[] args) throws IOException {
		Object[][] translations = readDataFromExcel(".\\Utilities\\TestDataMain.xlsx", "Sheet1");

		for (Object[] translation : translations) {
			String translationValue = (String) translation[0];
			triggerAPICall(translationValue);
		}
	}

	public static Object[][] readDataFromExcel(String filePath, String sheetName) throws IOException {
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook workbook = new XSSFWorkbook(file);
		Sheet sheet = workbook.getSheet(sheetName);

		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		Object[][] data = new Object[rowCount][1];

		for (int i = 0; i < rowCount; i++) {
			Row row = sheet.getRow(i + 1);
			data[i][0] = row.getCell(0).getStringCellValue();
		}

		return data;
	}

	public static void triggerAPICall(String translation) {
		String apiUrl = "https://restcountries.com/v3.1/translation/" + translation;
		Response response = RestAssured.given().get(apiUrl);
		System.out.println("URL: " + apiUrl);
		System.out.println("Response Code: " + response.getStatusCode());

	}

}
