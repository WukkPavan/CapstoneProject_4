package stepDefinitions;

import org.junit.Assert;
import org.testng.asserts.SoftAssert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.AorBPage;
import pageObjects.DropDownPage;
import pageObjects.FramesPage;
import pageObjects.HomePage;
import utilities.TestContextSetup;

public class Implementation {
	TestContextSetup testContextSetup;
	HomePage homepage;
	AorBPage aorbpage;
	DropDownPage dropdownpage;
	FramesPage framespage;
	SoftAssert sf;
	public Implementation(TestContextSetup testContextSetup) {
		this.testContextSetup = testContextSetup;
		this.homepage = testContextSetup.pageobjectManager.homepage();
		this.aorbpage = testContextSetup.pageobjectManager.aorbpage();
		this.dropdownpage = testContextSetup.pageobjectManager.dropdownpage();
		this.framespage = testContextSetup.pageobjectManager.framespage();
		sf = new SoftAssert();
	}
	@Given("Launch an url")
	public void launch_an_url() { 
	}
	@When("Click on A\\/B Testing link and verify the text on the page")
	public void click_on_a_b_testing_link_and_verify_the_text_on_the_page() {
	    homepage.clickA0rB();
	    String heading = aorbpage.getHeading();
	    System.out.println(heading);
	    sf.assertTrue(heading.equalsIgnoreCase("A/B Test Variation 1"));
	    
	}
	@When("Navigate back to Home page and click on dropdown link")
	public void navigate_back_to_home_page_and_click_on_dropdown_link() {
	    aorbpage.backtoHome();
	    homepage.clickDropDown();
	}
	@When("Select Option1 value form drop down and confirm if its selected or not")
	public void select_option1_value_form_drop_down_and_confirm_if_its_selected_or_not() {
	    dropdownpage.clickDropdown();
	    String attribute = dropdownpage.validateOption();
	    System.out.println(dropdownpage.validateOption());
	    sf.assertTrue(attribute.equalsIgnoreCase("true"));
	}
	@When("Navigate back to Home Page and Click on Frames")
	public void navigate_back_to_home_page_and_click_on_frames() {
	    dropdownpage.backtoHome();
	    homepage.clickFrames();
	}
	@Then("Verify the {string} and {string} hyperlinks are presented on the Frames Page")
	public void verify_the_and_hyperlinks_are_presented_on_the_frames_page(String string1, String string2) throws InterruptedException {
	    String str1 = framespage.getstringValOne();
	    String str2 = framespage.getStringValtwo();
		System.out.println(str1);
		sf.assertTrue(string1.equalsIgnoreCase(string1));
	    System.out.println(string2.equalsIgnoreCase(string2));
	    framespage.driverQuit();
	    sf.assertAll();
	}

}
