package pageObjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.BaseTest;

public class DropDownPage extends BaseTest{
	WebDriver driver;
	public DropDownPage(WebDriver driver) {
		this.driver = driver;
	}
	By dropdown = By.xpath("//select[@id='dropdown']");
	By option = By.cssSelector("option[value='1']");
	
	public void clickDropdown() {
		driver.findElement(dropdown).click();
	}
	public String validateOption() {
		new WebDriverWait(driver, Duration.ofSeconds(5))
		.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(option));
		driver.findElement(option).click();
		String val = driver.findElement(option).getAttribute("selected");
		return val;
	}
	public void backtoHome() {
		driver.navigate().back();
	}
}
