package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AorBPage {
	WebDriver driver;
	public AorBPage(WebDriver driver) {
		this.driver = driver;
	}
	By heading = By.cssSelector("div[class='example'] h3");
	
	public String getHeading() {
		return driver.findElement(heading).getText();
	}
	public void backtoHome() {
		driver.navigate().back();
	}
}
