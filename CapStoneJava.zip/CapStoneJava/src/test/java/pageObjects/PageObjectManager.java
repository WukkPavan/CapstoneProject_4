package pageObjects;

import org.openqa.selenium.WebDriver;

public class PageObjectManager {
	public WebDriver driver;
	public HomePage homepage;
	public AorBPage aorbPage;
	public DropDownPage dropdownpage;
	public FramesPage framesPage;
	
	public PageObjectManager(WebDriver driver) {
		this.driver = driver;
	}
	public HomePage homepage() {
		return new HomePage(driver);
	}
	public AorBPage aorbpage() {
		return new AorBPage(driver);
	}
	public DropDownPage dropdownpage() {
		return new DropDownPage(driver);
	}
	public FramesPage framespage() {
		return new FramesPage(driver);
	}
}
