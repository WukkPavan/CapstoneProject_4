package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FramesPage {
	WebDriver driver;
	public FramesPage(WebDriver driver) {
		this.driver = driver;
	}
	By NestedFramesLink = By.cssSelector("a[href='/nested_frames']");
	By iframe = By.cssSelector("a[href='/iframe']");
	
	public String getstringValOne() {
		return driver.findElement(NestedFramesLink).getText();
	}
	public String getStringValtwo() {
		return driver.findElement(iframe).getText();
	}
	public void driverQuit() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}
}
