package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	By AorBLink = By.linkText("A/B Testing");
	By DropDown = By.linkText("Dropdown");
	By Frames = By.linkText("Frames");
	
	public void clickA0rB() {
		driver.findElement(AorBLink).click();
	}
	public void clickDropDown() {
		driver.findElement(DropDown).click();
	}
	public void clickFrames() {
		driver.findElement(Frames).click();
	}
}
