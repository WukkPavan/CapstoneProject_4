package utilities;

import java.io.IOException;

import pageObjects.PageObjectManager;

public class TestContextSetup {
	public PageObjectManager pageobjectManager;
	public BaseTest baseTest;
	public TestContextSetup() throws IOException {
		baseTest = new BaseTest();
		pageobjectManager = new PageObjectManager(baseTest.initializeDriver());
	}
}
